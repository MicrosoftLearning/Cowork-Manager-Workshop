---
name: one-on-one-recap
description: |
  Drafts a reusable post-meeting follow-up for a manager's 1:1 with a named
  direct report, built from the meeting's Teams transcript. Excludes personal and
  opening small talk, and outputs a fixed format: key discussion points,
  decisions, action items split into the manager's vs. the report's (with owners
  and due dates), support the manager committed to, and the focus for the next
  1:1. Surfaces the draft to the manager for inline review and editing, and only
  sends it to the employee on explicit approval — it never auto-sends.
  Use when the user asks to "draft the follow-up for my 1:1 with <name>", "recap
  my one-on-one with <name>", "summarize my 1:1 with <name>", "send <name> a
  recap of our 1:1", "write up my 1:1 notes for <name>", or sets up a recurring
  post-1:1 recap for a direct report.
  Do NOT use for pre-meeting preparation — use one-on-one-prep instead. Do NOT
  use for multi-person meeting minutes or general meeting summaries — use
  meeting-intel instead.
cowork:
  category: productivity
  icon: DocumentEdit
---

## Overview
Turns the transcript of a manager's 1:1 into a clean, predictable recap for the
direct report. It strips the personal rapport-building at the top of the call,
keeps only the work, and separates who owns what. The manager reviews and edits
the draft before anything is sent — the send to the employee happens only on an
explicit "send it." The report's name is the only required input, so the same
skill works for every member of a team.

## When to Use
- Writing the follow-up right after a 1:1 with a specific direct report
- A repeatable recap the manager approves before it reaches the employee
- Capturing decisions and action items from the 1:1 transcript

## When NOT to Use
- Preparing **before** the meeting — use **one-on-one-prep**
- Minutes for a multi-person meeting or a general summary — use **meeting-intel**
- A team-wide status roll-up — use **team-pulse**

## Quick Start
```
User: "Draft the follow-up for today's 1:1 with Julia."
1. Resolve the report (SearchPeople) and find the 1:1 event (ListCalendarView)
2. Pull the transcript (join_url → ListMeetingTranscripts → GetMeetingTranscript)
3. Strip personal/opening small talk; keep only work content
4. Draft the recap in the Output format
5. Show it to the manager for review/edit — DO NOT send yet
6. On "send it," email the recap to the report (SendEmailWithAttachments)
```

## Core Instructions

### Step 1 — Resolve the report & meeting
- Resolve the named report with `SearchPeople` / `GetUserDetails`.
- Find the 1:1 event with `ListCalendarView` (match attendee + subject). Default
  to today's or the most recent past occurrence unless the user names another.

### Step 2 — Get the transcript
- From the matched event take `onlineMeeting.joinUrl` →
  `ListMeetingTranscripts(join_url=...)` → `GetMeetingTranscript(...)`.
- For a recurring series, pick the transcript whose `createdDateTime` is closest
  to the target occurrence's start.
- If no transcript exists yet, tell the manager (transcription may still be
  processing, or wasn't enabled) — do not fabricate content.

### Step 3 — Filter out the personal opening
- Drop rapport/small talk and personal content: greetings, weekend/family/health
  chat, vacation logistics, and anything clearly personal — these usually sit at
  the start of the call. Keep only work: decisions, commitments, blockers,
  feedback, priorities.
- When unsure whether a line is personal or work, **leave it out** and let the
  manager add it back during review.

### Step 4 — Draft the recap
- Fill the Output format. Attribute action items to an owner and give each a due
  date (use dates named in the call; otherwise mark `[due?]` for the manager).

### Step 5 — Review, then send only on approval
- Present the full draft to the manager inline for review and editing. Apply any
  edits they ask for by chat.
- **Only after an explicit approval ("send it", "looks good — send")** send the
  recap to the report via `SendEmailWithAttachments`. Never send without it.

## Output
An email draft **To: <Report>**, subject **"1:1 Recap — <date>"**, with:

- **Key discussion points** — 3–6 bullets of what you covered (work only).
- **Decisions** — what was decided (omit if none).
- **Action items**
  - *Yours:* owner = manager, with due dates.
  - *<Report>'s:* owner = report, with due dates.
- **Support I'll provide** — what the manager committed to unblock/accelerate.
- **Focus for our next 1:1** — 1–3 items to pick up next time.

Tone: warm, concise, professional. Target ≤ ~250 words.

## Guardrails
- **Never auto-send.** Always show the draft for review first; send to the report
  only on the manager's explicit approval. This is a hard rule.
- **Exclude personal content** discussed in the call; when in doubt, leave it out.
- **Ground in the transcript.** Every point, decision, and action item must come
  from the transcript — never invent commitments, dates, or quotes. If the
  transcript is missing, stop and tell the manager.
- **No performance evaluation** — capture work and commitments, not judgments of
  the report's ability.
- If the report or meeting can't be resolved, ask which person or occurrence to
  use rather than guessing.
